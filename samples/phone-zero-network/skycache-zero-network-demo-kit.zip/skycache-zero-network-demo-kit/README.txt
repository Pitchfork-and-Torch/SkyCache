SkyCache zero-network demo kit
===============================
Format: skycache-zero-network-kit-v1

GOAL
----
Read the three public-domain demo texts on a phone that has
  - NO Wi-Fi
  - NO cell / mobile data

HOW (physics)
-------------
You cannot download over the air without a radio. This kit is
**local files**. Put them on the phone by any of:

  1. USB / OTG cable from a PC or SkyCache hub
  2. microSD card (if the phone has a slot)
  3. Bluetooth file send from another device that already has the kit
  4. Copy before you leave town (pre-deploy)

Then open READ-OFFLINE.html in the phone browser or a file viewer.
Airplane mode is fine. No network is used.

CONTENTS
--------
  READ-OFFLINE.html     All-in-one offline reader (open this first)
  texts/*.txt           Plain text of each work
  kit-manifest.json     Integrity / inventory
  README.txt            This file

THE THREE TEXTS
---------------
  skybrary-pd-aesop-001       The Fox and the Grapes (Aesop)
  skybrary-pd-gettysburg-001  Gettysburg Address (Lincoln)
  skybrary-pd-hippocratic-001 Hippocratic Oath (PD excerpt)

LEGAL
-----
Public domain / educational samples only. Not medical advice.
Not a complete archive of written knowledge.
Not free Starlink or commercial satellite broadband.

Hub software: https://github.com/Pitchfork-and-Torch/SkyCache
Build kit:    skycache skybrary zero-network-kit --out ./kit
